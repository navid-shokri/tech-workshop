using System;
using System.Threading;
using System.Threading.Tasks;

namespace Mediator;

public class PingAnotherHandler : INotificationHandler<Ping>
{
    public ValueTask Handle(Ping notification, CancellationToken cancellationToken)
    {
        Console.WriteLine("Me too, Ping, Mee Too!!!");
        return new ValueTask();
    }
}