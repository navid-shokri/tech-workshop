namespace Mediator;

public class Ping :INotification
{
    
}